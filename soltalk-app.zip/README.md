# SolTalk

Prototype d'une messagerie Web3 avec Phantom sur Solana.